var searchData=
[
  ['increment',['increment',['../class_nav_bar_splitter.html#a750c73a8d07f0007cc2e978bac118758',1,'NavBarSplitter']]],
  ['indexof',['indexOf',['../class_nav_bar.html#a266821cb9764b56cfacd81973b3ba94d',1,'NavBar']]],
  ['insertpage',['insertPage',['../class_nav_bar.html#ac0bb1c58f83ec4353dd99beaa3fe3d56',1,'NavBar::insertPage(int index, QWidget *page)'],['../class_nav_bar.html#acacd9816c8c42d10a0fc982c374d8e9e',1,'NavBar::insertPage(int index, QWidget *page, const QString &amp;text)'],['../class_nav_bar.html#a05cdbcba5072c5baa9c456b5204087d4',1,'NavBar::insertPage(int index, QWidget *page, const QString &amp;text, const QIcon &amp;icon)']]],
  ['ispageenabled',['isPageEnabled',['../class_nav_bar.html#ae420554de1707e6e0c70a96b38a0781a',1,'NavBar']]],
  ['ispagevisible',['isPageVisible',['../class_nav_bar.html#a566345ec6b97867a761cb155d41b9136',1,'NavBar']]]
];
