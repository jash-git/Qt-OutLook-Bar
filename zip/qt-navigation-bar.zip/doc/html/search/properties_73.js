var searchData=
[
  ['showcollapsebutton',['showCollapseButton',['../class_nav_bar.html#a746af848ef80d6cfc14d44e72232ce4d',1,'NavBar']]],
  ['showheader',['showHeader',['../class_nav_bar.html#ad64e48b9cab631ffd18e6a29e22d37c3',1,'NavBar']]],
  ['showoptionsmenu',['showOptionsMenu',['../class_nav_bar.html#afd7fbc48d10af2d8a89abaf146b3085e',1,'NavBar']]],
  ['smalliconsize',['smallIconSize',['../class_nav_bar.html#abd5af291f9273af49469415339411df3',1,'NavBar']]]
];
