var searchData=
[
  ['removepage',['removePage',['../class_nav_bar.html#a5bdebb47417bfee027992f9753a80b86',1,'NavBar']]],
  ['restorestate',['restoreState',['../class_nav_bar.html#ace150d052fedc597fffad818dae23991',1,'NavBar']]],
  ['rowheight',['rowHeight',['../class_nav_bar.html#a1e99abd758accd2667223ed3c1c68311',1,'NavBar']]]
];
