var searchData=
[
  ['pageicon',['pageIcon',['../class_nav_bar.html#a4a71dfcef64798671896672a4f69e58d',1,'NavBar']]],
  ['pagetext',['pageText',['../class_nav_bar.html#ac35c6bf4f4266aa5cdcb8391a2f5f804',1,'NavBar']]]
];
