var searchData=
[
  ['widget',['widget',['../class_nav_bar.html#a98a5ec36278fd554e4f0614e11da5a21',1,'NavBar']]]
];
