var searchData=
[
  ['autopopup',['autoPopup',['../class_nav_bar.html#ac2342f2b72fe1780a0a0c14e798c4f22',1,'NavBar']]]
];
