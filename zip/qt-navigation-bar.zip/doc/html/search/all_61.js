var searchData=
[
  ['addpage',['addPage',['../class_nav_bar.html#aedf27f355d73164760e1f645590e5b20',1,'NavBar::addPage(QWidget *page)'],['../class_nav_bar.html#a042829d06339f41eff9c3a3950271373',1,'NavBar::addPage(QWidget *page, const QString &amp;text)'],['../class_nav_bar.html#a39ebd1d20f4250d653a08fdbf4a3884b',1,'NavBar::addPage(QWidget *page, const QString &amp;text, const QIcon &amp;icon)']]],
  ['autopopup',['autoPopup',['../class_nav_bar.html#ac2342f2b72fe1780a0a0c14e798c4f22',1,'NavBar']]]
];
