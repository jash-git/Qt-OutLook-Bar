var searchData=
[
  ['currentchanged',['currentChanged',['../class_nav_bar.html#ae9b436da1adb6306d615d1dcc9a5cdeb',1,'NavBar']]],
  ['currentwidget',['currentWidget',['../class_nav_bar.html#a13750e3fdf2448e12eca696737a49530',1,'NavBar']]]
];
