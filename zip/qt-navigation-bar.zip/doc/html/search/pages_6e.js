var searchData=
[
  ['navbar_3a_20outlook_2dlike_20navigation_20bar_20for_20qt',['NavBar: Outlook-like navigation bar for Qt',['../index.html',1,'']]]
];
