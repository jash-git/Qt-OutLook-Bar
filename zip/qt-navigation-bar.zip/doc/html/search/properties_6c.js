var searchData=
[
  ['largeiconsize',['largeIconSize',['../class_nav_bar.html#ac5c9bb2692316c6b35b62ed6a5a9a52a',1,'NavBar']]]
];
